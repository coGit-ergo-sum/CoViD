# CoViD
 C# model for the spread of CoViD19, implemented without any SIR equations.
