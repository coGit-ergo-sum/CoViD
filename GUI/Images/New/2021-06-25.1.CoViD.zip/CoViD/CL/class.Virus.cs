﻿using System;

namespace CoViD.CL
{
	public class Virus { }

}
