﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CoViD.CL
{
	/// <summary>
	/// it's an accumulation point for youngsters
	/// </summary>
	class School
	{
	}
}
