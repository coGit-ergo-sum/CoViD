﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CoViD.CL
{
	/// <summary>
	/// The accumulation point for mature people.
	/// </summary>
	class Workplace

	{
	}
}
