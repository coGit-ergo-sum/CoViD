﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CoViD.CL
{
	/// <summary>
	/// The starting point for every 'jorney'
	/// </summary>
	class Home
	{
	}
}
