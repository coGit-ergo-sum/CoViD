﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using Vi.Tools.Extensions.String;
using Vi.Tools.Extensions.Float;


namespace CoViD.GUI.Forms
{
	/// <summary>
	/// 
	/// </summary>
	public partial class Disease : Form
	{
		static Brush red = (Brush)Brushes.Red;
		static Brush black = (Brush)Brushes.Black;
		static Brush white = (Brush)Brushes.White;
		static Brush green = (Brush)Brushes.Lime;
		static Brush yellow = (Brush)Brushes.Yellow;
		static Brush orange = (Brush)Brushes.Orange;
		static Brush blue = (Brush)Brushes.Blue;
		static Brush darkRed = (Brush)Brushes.DarkRed;

		public Disease()
		{
			InitializeComponent();
			ledBlue.Location = ledWhite.Location;
		}

		private void Disease_Load(object sender, EventArgs e)
		{
			//timer1.Enabled = true;
			//this.btnNewEvolution_Click(null, null);
		}

		private void timer1_Tick(object sender, EventArgs e)
		{
			this.btnNewEvolution_Click(null, null);
			timer1.Enabled = false;
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void btnNewEvolution_Click(object sender, EventArgs e)
		{
			this.ledGreen.On = false;
			this.ledYellow.On = false;
			this.ledRed.On = false;
			this.ledBlue.On = false;
			this.ledWhite.On = false;
			var person = new CoViD.CL.Person(new List<CoViD.CL.Point>() { new CoViD.CL.Point(0, 0) });
			this.Loop(person);
		}

		private void Loop(CoViD.CL.Person person)
		{
			Single xMin = 0;
			Single yMin = 0;
			Single xMax = txtXMax.Text.ToFloat(1000);
			Single yVMax = txtYVMax.Text.ToFloat(1000 * 1000 * 1000);
			Single yAMax = txtYAMax.Text.ToFloat(150 * 1000 * 1000);

			this.xy1.Clear();
			this.xy2.Clear();

			this.xy1.SetX(xMin, xMax, xMin.ToString("#,##0"), xMax.ToString("#,##0"), "Time [ticks]");
			this.xy1.SetY(yMin, yVMax, yMin.ToString("#,##0"), yVMax.ToString("0.00 E+00"), "# Viruses [Unities of]");


			this.xy2.SetX(xMin, xMax, xMin.ToString("#,##0"), xMax.ToString("#,##0"), "Time [ticks]");
			this.xy2.SetY(yMin, yAMax, yMin.ToString("#,##0"), yAMax.ToString("0.00 E+00"), "# Antibodies [Unities of]");


			var viruses = udVirusesN.Value;
			Func<CoViD.CL.Point, float> person_Inhale = (location) => { return viruses; };
			person.Inhale += new CoViD.CL.Person.InhaleDelegate(person_Inhale);


			udVirusesGrowth.Value = person.VirusGrowthPercent * 100;
			udAntibodiesGrowth.Value = person.AntibodyGrowthPercent * 100;
			udAntibodiesDecay.Value = person.AntibodyDecayPercent * 100;


			int iMax = txtXMax.Text.ToInt(1000);

			bool isRed = false;
			bool isGreen = false;
			bool isYellow = false;
			bool isBlue = false;


			for (int i = 0; i < iMax; i++)
			{
				person.Tick();

				if (person.IsDead) { 
					//break; 
				}

				var color =
					person.IsSevere ? red :
					person.IsIll ? orange :
					person.IsIncubation ? green :
					person.IsDead ? blue :
					white;

				isGreen = isGreen || person.IsIncubation;
				isYellow = isYellow || person.IsIll;
				isRed = isRed || person.IsSevere;
				isBlue = isBlue || person.IsDead;

				this.xy1.Point(i, person.Viruses, color);
				this.xy2.Point(i, person.Antibodies, color);
			}
			{
				lblVmax2.Text = person.VirusesMaximumPercent.ToPercent2();  /////ToString("##0.00");
			}

			this.ledGreen.On = isGreen;
			this.ledYellow.On = isYellow;
			this.ledRed.On = isRed;
			this.ledBlue.On = isBlue;
			this.ledWhite.On = !isBlue;			
			
			this.ledBlue.Visible = isBlue;
			this.ledWhite.Visible = !isBlue;

		}

		private void ud_Click(object sender, EventArgs e) 
		{
			var virusGrowthPercent = udVirusesGrowth.Value / 100F;
			var virusesLimit = 1000 * 1000 * 1000;
			var antibodyGrowthPercent = udAntibodiesGrowth.Value / 100;
			var antibodyDecayPercent = udAntibodiesDecay.Value / 100;
			var deadThresholdPercent = 0.95F;

			var person = new CoViD.CL.Person(virusGrowthPercent, virusesLimit, antibodyGrowthPercent, antibodyDecayPercent, deadThresholdPercent);

			Loop(person);
		}


	}
}