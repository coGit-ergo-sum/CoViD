﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Vi.Tools.Extensions.Random;

namespace CoViD.GUI.Forms
{
	public partial class Spread : Form
	{

		private CoViD.CL.World World;
		private CoViD.CL.Popolation Popolation;

		public Spread()
		{
			InitializeComponent();
		}

		private void Spread_Load(object sender, EventArgs e)
		{
			int radius = 1000 * 1;
			this.area1.SetXY(radius);
			this.udPoint.Value = this.udRadius.Value;
			Initialize();
		}



		private void Initialize()
		{
			Random rnd = new Random();

			this.area1.SetXY((int)udRadius.Value);

			var xMin = -this.area1.Radius;
			var xMax = this.area1.Radius;

			var yMin = -this.area1.Radius;
			var yMax = this.area1.Radius;

			var count = this.udPeople.Value;
			byte steps = (byte)udSteps.Value;


			Func<int, List<CoViD.CL.Point>> getLocations = (index) =>
			{
				int x = rnd.Next(xMin, xMax, iterations: steps);
				int y = rnd.Next(yMin, yMax, iterations: steps);

				var locations = new List<CoViD.CL.Point>() { new CoViD.CL.Point(x, y) };
				return locations;
			};

			//////////////this.World = new CoViD.CL.World(this.area1.Radius * 2, this.area1.Radius * 2);
			this.World = new CoViD.CL.World(this.area1.Radius);
			this.Popolation = new CoViD.CL.Popolation();

			for (int i = 0; i < count; i++)
			{
				var locations = getLocations(i);
				var person = new CoViD.CL.Person(locations);
				person.Sneeze += this.Person_Sneeze;
				person.Inhale += this.Person_Inhale;

				this.Popolation.Add(person);
			}

			// ------------------------------------------------------------------------------------- //
			// Simulate the sneeze of the first infected person. This create a contaminated area
			var location = new CoViD.CL.Point(0, 0);
			Person_Sneeze(1, location);
			// ------------------------------------------------------------------------------------- //

		}


		private void button1_Click(object sender, EventArgs e)
		{
			var rnd = new Random();

			for (int i = -990; i < 991; i++)
			{
				{
					var x = rnd.Next(-this.area1.Radius, this.area1.Radius, 1);
					var y = rnd.Next(-this.area1.Radius, this.area1.Radius, 1);
					this.area1.Point(x, y, Color.Red);
				}
				{
					var x = rnd.Next(-this.area1.Radius, this.area1.Radius, 3);
					var y = rnd.Next(-this.area1.Radius, this.area1.Radius, 3);
					this.area1.Point(x, y, Color.Green);
				}
			}
		}




		private void up_Click(object sender, EventArgs e)
		{
			this.area1.Clear();
			this.Initialize();
			btnPeople_Click(null, null);
		}

		private float Person_Inhale(CoViD.CL.Point location)
		{
			if (location != null)
			{
				return 50; // this.World.Contamination[location.X + this.area1.Radius, location.Y + this.area1.Radius];
			}
			else
			{
				return 50;
			}
		}

		private void Person_Sneeze(float viruses, CoViD.CL.Point location)
		{
			//this.World.Contaminate(viruses, location, radius: 100);
		}

		private void btnPeople_Click(object sender, EventArgs e)
		{
			this.led1.Color = UC.Led.Colors.Red;
			this.led1.On = true;
			Application.DoEvents();
			foreach (var persona in this.Popolation)
			{
				Color color =
					persona.IsRecovering ? Color.Black :
					persona.IsWorsening ? Color.Yellow :
					Color.Black;

				var location = persona.Location;
				this.area1.Point(location.X, location.Y, color);
			}

			this.led1.Color = UC.Led.Colors.Green;
			Application.DoEvents();
		}

		private void udPoint_Click(object sender, EventArgs e)
		{
			this.area1.Clear();
			this.area1.Point(-this.udPoint.Value, this.udPoint.Value, Color.Red);
			this.area1.Point(this.udPoint.Value, this.udPoint.Value, Color.Red);
			this.area1.Point(this.udPoint.Value, -this.udPoint.Value, Color.Red);
			this.area1.Point(-this.udPoint.Value, -this.udPoint.Value, Color.Red);
		}

		private void btnRun_Click(object sender, EventArgs e)
		{
			for (int x = 0; x < 2000; x++) {

				this.led2.Caption = x.ToString("#,##0");
				this.led2.Color = UC.Led.Colors.Red;
				this.led2.On = true;
				Application.DoEvents();

				var btn = (Button)sender;
				btn.Visible = false;

				this.Popolation.Tick();
				this.World.Tick();

				btn.Visible = true;
				this.led2.Color = UC.Led.Colors.Green;
				Application.DoEvents();

				System.Threading.Thread.Sleep(0);

				btnPeople_Click(null, null);
			}
		}

	}
}
