﻿namespace CoViD.GUI.Forms
{
	partial class Spread
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.button1 = new System.Windows.Forms.Button();
			this.btnPeople = new System.Windows.Forms.Button();
			this.btnRun = new System.Windows.Forms.Button();
			this.led2 = new CoViD.GUI.UC.Led();
			this.udPoint = new CoViD.GUI.UC.UpDown();
			this.led1 = new CoViD.GUI.UC.Led();
			this.udSteps = new CoViD.GUI.UC.UpDown();
			this.udPeople = new CoViD.GUI.UC.UpDown();
			this.udRadius = new CoViD.GUI.UC.UpDown();
			this.area1 = new CoViD.GUI.UC.Area();
			this.SuspendLayout();
			// 
			// button1
			// 
			this.button1.Location = new System.Drawing.Point(1, 2);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(75, 23);
			this.button1.TabIndex = 2;
			this.button1.Text = "button1";
			this.button1.UseVisualStyleBackColor = true;
			this.button1.Click += new System.EventHandler(this.button1_Click);
			// 
			// btnPeople
			// 
			this.btnPeople.Location = new System.Drawing.Point(94, 2);
			this.btnPeople.Name = "btnPeople";
			this.btnPeople.Size = new System.Drawing.Size(75, 23);
			this.btnPeople.TabIndex = 8;
			this.btnPeople.Text = "People";
			this.btnPeople.UseVisualStyleBackColor = true;
			this.btnPeople.Click += new System.EventHandler(this.btnPeople_Click);
			// 
			// btnRun
			// 
			this.btnRun.Location = new System.Drawing.Point(275, 3);
			this.btnRun.Name = "btnRun";
			this.btnRun.Size = new System.Drawing.Size(75, 23);
			this.btnRun.TabIndex = 13;
			this.btnRun.Text = "Run";
			this.btnRun.UseVisualStyleBackColor = true;
			this.btnRun.Click += new System.EventHandler(this.btnRun_Click);
			// 
			// led2
			// 
			this.led2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.led2.Caption = "label1";
			this.led2.Color = CoViD.GUI.UC.Led.Colors.Grey;
			this.led2.Location = new System.Drawing.Point(356, 4);
			this.led2.MaximumSize = new System.Drawing.Size(381, 22);
			this.led2.MinimumSize = new System.Drawing.Size(22, 22);
			this.led2.Name = "led2";
			this.led2.On = true;
			this.led2.Size = new System.Drawing.Size(94, 22);
			this.led2.TabIndex = 14;
			// 
			// udPoint
			// 
			this.udPoint.Caption = "Caption";
			this.udPoint.Decimals = ((sbyte)(0));
			this.udPoint.Location = new System.Drawing.Point(492, 93);
			this.udPoint.MaximumSize = new System.Drawing.Size(335, 45);
			this.udPoint.MinimumSize = new System.Drawing.Size(162, 45);
			this.udPoint.Name = "udPoint";
			this.udPoint.Size = new System.Drawing.Size(210, 45);
			this.udPoint.TabIndex = 12;
			this.udPoint.Value = 0F;
			this.udPoint.Click += new System.EventHandler(this.udPoint_Click);
			// 
			// led1
			// 
			this.led1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.led1.Caption = "label1";
			this.led1.Color = CoViD.GUI.UC.Led.Colors.Grey;
			this.led1.Location = new System.Drawing.Point(175, 3);
			this.led1.MaximumSize = new System.Drawing.Size(381, 22);
			this.led1.MinimumSize = new System.Drawing.Size(22, 22);
			this.led1.Name = "led1";
			this.led1.On = true;
			this.led1.Size = new System.Drawing.Size(94, 22);
			this.led1.TabIndex = 11;
			// 
			// udSteps
			// 
			this.udSteps.Caption = "Steps";
			this.udSteps.Decimals = ((sbyte)(0));
			this.udSteps.Location = new System.Drawing.Point(256, 94);
			this.udSteps.MaximumSize = new System.Drawing.Size(335, 45);
			this.udSteps.MinimumSize = new System.Drawing.Size(162, 45);
			this.udSteps.Name = "udSteps";
			this.udSteps.Size = new System.Drawing.Size(217, 45);
			this.udSteps.TabIndex = 10;
			this.udSteps.Value = 2F;
			this.udSteps.Click += new System.EventHandler(this.up_Click);
			// 
			// udPeople
			// 
			this.udPeople.Caption = "People";
			this.udPeople.Decimals = ((sbyte)(0));
			this.udPeople.Location = new System.Drawing.Point(12, 93);
			this.udPeople.MaximumSize = new System.Drawing.Size(335, 45);
			this.udPeople.MinimumSize = new System.Drawing.Size(162, 45);
			this.udPeople.Name = "udPeople";
			this.udPeople.Size = new System.Drawing.Size(227, 45);
			this.udPeople.TabIndex = 9;
			this.udPeople.Value = 10000F;
			this.udPeople.Click += new System.EventHandler(this.up_Click);
			// 
			// udRadius
			// 
			this.udRadius.Caption = "Radius";
			this.udRadius.Decimals = ((sbyte)(0));
			this.udRadius.Location = new System.Drawing.Point(12, 42);
			this.udRadius.MaximumSize = new System.Drawing.Size(335, 45);
			this.udRadius.MinimumSize = new System.Drawing.Size(162, 45);
			this.udRadius.Name = "udRadius";
			this.udRadius.Size = new System.Drawing.Size(227, 45);
			this.udRadius.TabIndex = 6;
			this.udRadius.Value = 10000F;
			this.udRadius.Click += new System.EventHandler(this.up_Click);
			// 
			// area1
			// 
			this.area1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.area1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
			this.area1.Label = "Title";
			this.area1.Location = new System.Drawing.Point(-1, 156);
			this.area1.MinimumSize = new System.Drawing.Size(458, 497);
			this.area1.Name = "area1";
			this.area1.Size = new System.Drawing.Size(716, 527);
			this.area1.TabIndex = 0;
			// 
			// Spread
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(714, 691);
			this.Controls.Add(this.led2);
			this.Controls.Add(this.btnRun);
			this.Controls.Add(this.udPoint);
			this.Controls.Add(this.led1);
			this.Controls.Add(this.udSteps);
			this.Controls.Add(this.udPeople);
			this.Controls.Add(this.btnPeople);
			this.Controls.Add(this.udRadius);
			this.Controls.Add(this.button1);
			this.Controls.Add(this.area1);
			this.MinimumSize = new System.Drawing.Size(730, 730);
			this.Name = "Spread";
			this.Text = "Spread";
			this.Load += new System.EventHandler(this.Spread_Load);
			this.ResumeLayout(false);

		}

		#endregion

		private UC.Area area1;
		private System.Windows.Forms.Button button1;
		private UC.UpDown udRadius;
		private System.Windows.Forms.Button btnPeople;
		private UC.UpDown udPeople;
		private UC.UpDown udSteps;
		private UC.Led led1;
		private UC.UpDown udPoint;
		private System.Windows.Forms.Button btnRun;
		private UC.Led led2;
	}
}